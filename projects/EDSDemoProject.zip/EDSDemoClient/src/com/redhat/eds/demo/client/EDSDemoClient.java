package com.redhat.eds.demo.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.redhat.eds.demo.engine.TeiidSQLEngine;

/**
 * Teiid JDBC Client
 * 
 * @author Kaushik Bhattacharya
 * 
 */
public class EDSDemoClient {

	private static Properties config;

	// Load configuration
	private void init() throws IOException {
		config = new Properties();
		try {
			config.load(new FileInputStream("eds-demo.properties"));
		} catch (FileNotFoundException e) {
			System.err
					.println("The config file eds-demo.properties needs to be on the classpath");
			System.exit(-1);
		}

	}

	public static void main(String[] args) throws Exception {

		EDSDemoClient.class.newInstance().init();
		// Check for command line args
		if (args.length < 1) {
			System.out.println("usage: JDBCClient <sql-command>");
			System.exit(-1);
		}

		// Check for type of SQL
		if (args[0].toUpperCase().startsWith("SELECT")) {
			TeiidSQLEngine.getInstance().executeQuery(config, args[0]);
		} else {
			TeiidSQLEngine.getInstance().execute(config, args[0]);
		}
	}
}
