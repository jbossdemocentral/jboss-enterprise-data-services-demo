package com.redhat.eds.demo.engine;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.teiid.client.RequestMessage.ShowPlan;
import org.teiid.jdbc.TeiidStatement;

import com.redhat.eds.demo.access.TeiidConnectionManager;

/**
 * Executes queries on the Teiid VDB
 * 
 * @author Kaushik Bhattacharya
 * 
 */
public final class TeiidSQLEngine {

	private static TeiidSQLEngine teiidSQLEngine = new TeiidSQLEngine();

	// Prevent instantiation
	private TeiidSQLEngine() {

	}

	/**
	 * Get instance of TeiidSQLEngine
	 * 
	 * @return TeiidSQLEngine
	 */
	public static TeiidSQLEngine getInstance() {
		return teiidSQLEngine;
	}

	/**
	 * Get environment settings
	 * 
	 * @param config
	 *            Properties object containing values of eds-demo.properties
	 * @return Connection
	 * @throws Exception
	 */
	private Connection getConnection(Properties config) throws Exception {
		return TeiidConnectionManager.getInstance().getDataSourceConnection(
				config.getProperty("host"), config.getProperty("port"),
				config.getProperty("user"), config.getProperty("password"),
				config.getProperty("vdb"),
				ShowPlan.valueOf(config.getProperty("showPlan").toUpperCase()));
	}

	/**
	 * Execute Select query
	 * 
	 * @param config
	 *            env settings
	 * @param sql
	 *            query
	 * @throws Exception
	 */
	public void executeQuery(Properties config, String sql) throws Exception {

		Connection connection = getConnection(config);

		try {

			Statement statement = connection.createStatement();
			ResultSet results = statement.executeQuery(sql);

			ResultSetMetaData metadata = results.getMetaData();
			int columns = metadata.getColumnCount();

			System.out.println("Results:");
			// Display column names
			displayResults(null, metadata, columns);
			System.out.println();
			// Display data
			for (int row = 1; results.next(); row++) {
				displayResults(results, null, columns);
				System.out.println();
			}

			showPlan(config, statement);

			results.close();
			statement.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.close();
			}
		}
	}

	private void displayResults(ResultSet results, ResultSetMetaData metadata,
			int columns) throws SQLException {
		for (int column = 0; column < columns; column++) {
			if (column > 0) {
				System.out.print(",");
			}
			if (results != null) {
				System.out.print(results.getString(column + 1));
			}
			if (metadata != null) {
				System.out.print(metadata.getColumnName(column + 1));
			}

		}
	}

	/**
	 * Execute Insert/Update/Delete query
	 * 
	 * @param config
	 *            env settings
	 * @param sql
	 *            query
	 * @throws Exception
	 */
	public void execute(Properties config, String sql) throws Exception {
		Connection connection = getConnection(config);
		try {
			Statement statement = connection.createStatement();
			statement.execute(sql);
			showPlan(config, statement);

			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (connection != null) {
				connection.close();
			}
		}
	}

	private void showPlan(Properties config, Statement statement)
			throws SQLException {
		if (ShowPlan.ON.name().equals(
				config.getProperty("showPlan").toUpperCase())) {

			System.out.println("Query Plan");
			System.out.println(statement.unwrap(TeiidStatement.class)
					.getPlanDescription());
		}
	}
}
