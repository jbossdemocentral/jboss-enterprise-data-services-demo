package com.redhat.eds.demo.access;

import java.sql.Connection;

import org.teiid.client.RequestMessage.ShowPlan;
import org.teiid.jdbc.TeiidDataSource;

/**
 * Provide access to Teiid VDB through TeiidDataSource
 * 
 * @author Kaushik Bhattacharya
 * 
 */
public final class TeiidConnectionManager {

	private static TeiidConnectionManager teiidConnectionManager = new TeiidConnectionManager();

	// Prevent instantiation
	private TeiidConnectionManager() {

	}

	/**
	 * Get instance of TeiidConnectionManager
	 * 
	 * @return TeiidConnectionManager
	 */
	public static TeiidConnectionManager getInstance() {
		return teiidConnectionManager;
	}

	/**
	 * Get connection to Teiid DS
	 * 
	 * @param host
	 *            hostname
	 * @param port
	 *            port
	 * @param user
	 *            Teiid user
	 * @param password
	 *            Teiid password
	 * @param vdb
	 *            Teiid Virtual DB (Deployed in SOA-P)
	 * @param showPlan
	 *            Show SQL plan
	 * @return Connection
	 * @throws Exception
	 */
	public Connection getDataSourceConnection(String host, String port,
			String user, String password, String vdb, ShowPlan showPlan)
			throws Exception {
		final TeiidDataSource ds = new TeiidDataSource();
		ds.setDatabaseName(vdb);
		ds.setUser(user);
		ds.setPassword(password);
		ds.setServerName(host);
		ds.setPortNumber(Integer.valueOf(port));

		ds.setShowPlan(showPlan.name());

		return ds.getConnection();
	}

}
